import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import './Card.css';

const useStyles = makeStyles({
  card: {
    minWidth: 275,
  },
  bullet: {
    display: 'inline-block',
    margin: '0 2px',
    transform: 'scale(0.8)',
  },
  title: {
    fontSize: 14,
  },
  pos: {
    marginBottom: 12,
  },
});

 const SimpleCard = (props) => {
    
  const classes = useStyles();

 

  return (
    <Card className={classes.card}>
      <CardContent>
        <div className={
             "header " +
             (props.carddata.alarmCount > 0 ? "colorRed" : "colorBlue")
        } >
            <div className="headerContent">
            <p className="mediumContent"> { props.carddata.title }</p>
            <p className="smallerContent"> { props.carddata.subtitle }</p>
            <p className="smallestContent"> {props.carddata.deviceCount ? props.carddata.deviceCount : "0"} Devices</p>
            </div>
        </div>
        <div className="container-content">
        <div className="content">
            <p className = {!props.carddata.alarmCount && "colorRedC"}> {props.carddata.alarmCount ? props.carddata.alarmCount  : "0" } Alarm </p>
            <p className = {props.carddata.eventCount  && "colorBlueC"}> {props.carddata.eventCount ?props.carddata.eventCount : "0"} Event </p>
            <p> {props.carddata.commStatus ? props.carddata.commStatus : "0"}  </p>
        </div>
      
           
            {
                props && props.carddata &&  props.carddata.values &&
                props.carddata.values  && 
                Object.keys(props.carddata.values).map( key => 
                key && <div className="content">  
               
                <p> {props.carddata.values[key]}  {key ==="temperature" ? "F" : "" }
                {key ==="humidity" ? "%" : "" }
                {key ==="flow" ? "KSCFH" : "" }
                {key ==="volume" ? "KSCF" : "" }</p> 
                <p className="camelCase"> {key} </p> 
               
                </div>)
            }
           
       
</div>
      </CardContent>
      <CardActions>
        <span className="viewLocation">View Location</span>
      </CardActions>
    </Card>
  );
}

export default SimpleCard;
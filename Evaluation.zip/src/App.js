import React,{ useEffect, useState} from 'react';
import './App.css';
import Card from './Card'

const App = ()=> {

  const [hasError, setErrors] = useState(false);
  const [data, setData] = useState({});

  async function fetchData() {
    const res = await fetch("./sampleData.json"); // can be changed to server
    res
      .json()
      .then(res => setData(res))
      .catch(err => setErrors(err));
  }


  

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="App">
     
      <div className="flex-container">
      { 
        data  && data.map && data.map ( cardData => (
         <div key={cardData.title} className="card" ><Card carddata={cardData}/></div>
       ))
       }
      </div>
     
      </div>
  );
}

export default App;
